Downloaded from SkyMods:

http://smods.ru
https://plus.google.com/u/0/communities/100644482381435508067

Cities: Skylines Mods Catalogue

HOW TO INSTALL MODS

Place mod folder or mod.dll and other contents(if required) here:

C:\Users\<USER NAME>\AppData\Local\Colossal Order\Cities_Skylines\Addons\Mods\[PUT FILES & FOLDERS HERE]

HOW TO INSTALL ASSETS

Place assets.crp files(folders) here:

C:\Users\<USER NAME>\AppData\Local\Colossal Order\Cities_Skylines\Addons\Assets\[PUT FILES & FOLDERS HERE]

HOW TO INSTALL MAPS

Place your maps(folders) here:

C:\Users\<USER NAME>\AppData\Local\Colossal Order\Cities_Skylines\Maps\[PUT FILES & FOLDERS HERE]

HOW TO INSTALL COLOR CORRECTIONS

Place your colorcorrection.crp files(folders) here:

C:\Users\<USER NAME>\AppData\Local\Colossal Order\Cities_Skylines\Addons\ColorCorrections\[PUT FILES & FOLDERS HERE]